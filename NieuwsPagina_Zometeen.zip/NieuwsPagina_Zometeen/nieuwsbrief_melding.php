<!-- Jochem Kroep -->
<div class="nieuwsbrief">
    <p><a class="text_melding" href="nieuwsbrief_aanmelden.php">Meld je hier aan voor de nieuwsbrief!</a></p>
</div>