<!-- Jochem Kroep -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="footer">
      <table>
        <tr>
            <th class="voorpagina_footer">Voorpagina</th>
            <th class="economie_footer">Economie</th>
            <th class="sport_footer">Sport</th>
            <th class="mediacultuur_footer">Media en Cultuur</th>
            <th class="overig_footer">Overig</th>
           
        </tr>
        <tr>
            <td>Net binnen</td>
            <td>Klimaat</td>
            <td>Voetbal</td>
            <td>Films en series</td>
            <td>Het woord</td>
        </tr>
        <tr>
            <td>Meest gelezen</td>
            <td>Tech</td>
            <td>Formule 1</td>
            <td>Muziek</td>
            <td>Dieren</td>
        </tr>
        <tr>
            <td>Oorlog</td>
            <td>Wonen</td>
            <td>Scorebord</td>
            <td>Boek en Cultuur</td>
            <td>Dieren</td>
        </tr>
        <tr>
            <td>Binnenland</td>
            <td>Geld</td>
            <td>Sportspellen</td>
            <td>Media</td>
            <td>Eten en drinken</td>
        </tr>
        <tr>
            <td>Buitenland</td>
            <td>Werk</td>
            <td></td>
            <td>Achterklap</td>
            <td>Gezondheid</td>
        </tr>
        <tr>
            <td>Algemeen</td>
            <td>Auto</td>
            <td></td>
            <td>Koningshuis</td>
            <td>NUcheckt</td>
        </tr>
        <tr>
            <td>Politiek</td>
            <td>Aandelen</td>
            <td></td>
            <td>TV gids</td>
            <td>Opmerkelijk</td>
        </tr>
        <tr>
            <td>Uit andere media</td>
            <td></td>
            <td></td>
            <td></td>
            <td>Wetenschap</td>
        </tr>
        <tr>
            <td>Video</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>Podcast</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>Weer</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
      </table>
    </div>
</body>
</html>