window.onload = function() {
    var klikElement = document.getElementById("klikElement");
    var verborgenTekst = document.getElementById("verborgenTekst");

    // Event handler toevoegen aan het klikElement
    klikElement.onclick = function() {
        // Controleren of de verborgen tekst zichtbaar is
        if (verborgenTekst.style.display === "none") {
            // Als de verborgen tekst verborgen is, weergeven
            verborgenTekst.style.display = "block";
            // Tekst van het klikElement aanpassen
            klikElement.innerHTML = "Voorwaarden verbergen";
        } else {
            // Als de verborgen tekst zichtbaar is, verbergen
            verborgenTekst.style.display = "none";
            // Tekst van het klikElement aanpassen
            klikElement.innerHTML = "Voorwaarden";
        }
    };
};
